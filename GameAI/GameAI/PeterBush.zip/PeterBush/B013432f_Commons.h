#pragma once

enum TankState
{
	Idle,
	Moving,
	Shooting,
	Dead,
	Hiding,
	Targeting
};


