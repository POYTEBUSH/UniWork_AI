//#pragma once
//#include "../BaseTank.h"
//#include "B013432f_Commons.h"
//#include "B013432f_Tank.h"
//
//class B013432f_FuSM
//{
//public:
//	B013432f_FuSM();
//	~B013432f_FuSM();
//
//	//TankState GetTankState() const { return _tank->GetState(); };
//
//	virtual void EnterState() = 0;
//	virtual void ExitState();
//	virtual void Update(float deltaTime);
//	
//private:	
//	B013432f_Tank* _tank;
//
//	vector<TankState*> mStates{  };
//	vector<TankState*> mActivatedStates;
//};
//
