//#pragma once
//
//#include "B013432f_FuSMManager.h"
//
//B013432f_FuSM::B013432f_FuSM()
//{
//}
//
//void B013432f_FuSM::Update(float deltaTime)
//{
//	if (mStates.size() == 0)
//		return;
//
//	vector<TankState*> previouslyActiveStates = mActivatedStates;
//
//	mActivatedStates.clear();
//
//	vector<TankState*> nonActiveStates;
//
//	/*for (int i = 0; i < mStates.size(); i++)
//	{
//		if (mStates[i]->CalculateActivation() > 0)
//			mActivatedStates.push_back(mStates[i]);
//		else
//			nonActiveStates.push_back(mStates[i]);
//	}*/
//}
